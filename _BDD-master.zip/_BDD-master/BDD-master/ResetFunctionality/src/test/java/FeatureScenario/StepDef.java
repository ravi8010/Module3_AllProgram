package FeatureScenario;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	@Given("^Open the Firefox and Launch the application$")
	public void open_the_Firefox_and_Launch_the_application() throws Throwable {

		
	}

	@When("^Enter the Username \"([^\"]*)\" and Password \"([^\"]*)\"$")
	public void enter_the_Username_and_Password(String arg1, String arg2) throws Throwable {
		
	}

	@Then("^Reset the credential$")
	public void reset_the_credential() throws Throwable {
		
	}

}
