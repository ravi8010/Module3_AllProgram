package FeatureReset;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

@Given("^Open the Firefox and launch the application$")
public void open_the_Firefox_and_launch_the_application() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^Enter the Username And Password$")
public void enter_the_Username_And_Password() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Reset The credential$")
public void reset_The_credential() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}


}
