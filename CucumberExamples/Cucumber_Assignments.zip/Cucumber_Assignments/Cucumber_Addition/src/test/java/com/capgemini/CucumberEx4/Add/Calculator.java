package com.capgemini.CucumberEx4.Add;

public class Calculator {

	public int add(int a, int b) {
		return a + b;
	}
}
